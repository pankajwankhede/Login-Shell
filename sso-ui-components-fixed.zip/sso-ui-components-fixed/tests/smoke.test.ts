import { describe, expect, it } from "vitest";
import { Button, PublicLayout, TextField } from "../src/index";

describe("public exports", () => {
  it("exports reusable components", () => {
    expect(Button).toBeTypeOf("function");
    expect(TextField).toBeTypeOf("function");
    expect(PublicLayout).toBeTypeOf("function");
  });
});
