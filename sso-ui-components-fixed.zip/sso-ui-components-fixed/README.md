# @company/sso-ui-components

Reusable React layouts and form components for the enterprise SSO platform.

## Local workspace prerequisite

Keep this repository beside `sso-auth-core`:

```text
sso-platform-workspace/
├── sso-auth-core/
└── sso-ui-components/
```

The development dependency uses:

```json
"@company/sso-auth-core": "file:../sso-auth-core"
```

Build `sso-auth-core` first, then this package.

## Build locally

```bash
cd ../sso-auth-core
npm install
npm run build

cd ../sso-ui-components
npm install
npm run typecheck
npm run test
npm run build
```

Expected output:

```text
dist/
├── index.js
├── index.js.map
├── index.d.ts
└── styles.css
```

## Test the package before Nexus

```bash
npm pack
```

Then from `sso-react-shell`:

```bash
npm uninstall @company/sso-ui-components
npm install ../sso-ui-components/company-sso-ui-components-0.1.0.tgz
```

## Consumer imports

```tsx
import {
  PublicLayout,
  AuthenticatedLayout,
  Button,
  TextField,
  PasswordField,
  Alert,
  LoadingPage,
} from "@company/sso-ui-components";

import "@company/sso-ui-components/styles.css";
```

Do not import an internal path such as:

```ts
import "@company/sso-ui-components/dist/styles.css";
```

## Publish to Nexus

Update `publishConfig.registry` in `package.json`, configure `.npmrc`, and run:

```bash
npm publish
```
