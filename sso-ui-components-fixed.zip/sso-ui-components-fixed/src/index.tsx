import React, { useEffect, type ReactNode } from "react";
import type { UiConfig } from "@company/sso-auth-core";
import "./styles.css";

export interface LayoutProps {
  config: UiConfig;
  children: ReactNode;
}

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "link";
  loading?: boolean;
}

export interface TextFieldProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  id: string;
  label: string;
  error?: string;
  hint?: string;
}

function Meta({ config }: { config: UiConfig }) {
  useEffect(() => {
    document.title = config.pageTitle;

    if (!config.faviconUrl) {
      return;
    }

    let favicon = document.querySelector<HTMLLinkElement>(
      'link[rel="icon"]',
    );

    if (!favicon) {
      favicon = document.createElement("link");
      favicon.rel = "icon";
      document.head.appendChild(favicon);
    }

    favicon.href = config.faviconUrl;
  }, [config]);

  return null;
}

function Links({ links }: { links: UiConfig["headerLinks"] }) {
  return (
    <>
      {links.map((link) => (
        <a
          key={link.id}
          href={link.url}
          target={link.target}
          rel={
            link.target === "_blank"
              ? "noopener noreferrer"
              : undefined
          }
          className="sso-link"
        >
          {link.label}
        </a>
      ))}
    </>
  );
}

export function PublicLayout({ config, children }: LayoutProps) {
  return (
    <div className="sso-layout sso-layout--public">
      <Meta config={config} />
      <header className="sso-header sso-header--public">
        <div className="sso-header__inner">
          {config.logoUrl ? (
            <img
              src={config.logoUrl}
              alt={config.logoAlt ?? "Application logo"}
              className="sso-logo"
            />
          ) : null}
          <nav className="sso-nav" aria-label="Header links">
            <Links links={config.headerLinks ?? []} />
          </nav>
        </div>
      </header>

      <main className="sso-main">
        <section className="sso-card">{children}</section>
      </main>

      <footer className="sso-footer">
        <div className="sso-footer__inner">
          <span>{config.footerText}</span>
          <nav className="sso-nav" aria-label="Footer links">
            <Links links={config.footerLinks ?? []} />
          </nav>
        </div>
      </footer>
    </div>
  );
}

export function AuthenticatedLayout({ config, children }: LayoutProps) {
  return (
    <div className="sso-layout sso-layout--authenticated">
      <Meta config={config} />
      <header className="sso-header sso-header--authenticated">
        <div className="sso-header__inner">
          {config.logoUrl ? (
            <img
              src={config.logoUrl}
              alt={config.logoAlt ?? "Application logo"}
              className="sso-logo"
            />
          ) : null}
          <nav className="sso-nav" aria-label="Header links">
            <Links links={config.headerLinks ?? []} />
          </nav>
        </div>
      </header>

      <main className="sso-main">
        <section className="sso-card sso-card--wide">{children}</section>
      </main>

      <footer className="sso-footer">
        <div className="sso-footer__inner">
          <span>{config.footerText}</span>
          <nav className="sso-nav" aria-label="Footer links">
            <Links links={config.footerLinks ?? []} />
          </nav>
        </div>
      </footer>
    </div>
  );
}

export function Button({
  variant = "primary",
  loading = false,
  disabled,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      disabled={disabled || loading}
      className={`sso-button sso-button--${variant} ${
        props.className ?? ""
      }`.trim()}
    >
      {loading ? "Please wait…" : children}
    </button>
  );
}

export function TextField({
  id,
  label,
  error,
  hint,
  className,
  ...props
}: TextFieldProps) {
  const hintId = hint ? `${id}-hint` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined;

  return (
    <div className={`sso-field ${className ?? ""}`.trim()}>
      <label htmlFor={id} className="sso-field__label">
        {label}
      </label>
      <input
        {...props}
        id={id}
        aria-invalid={Boolean(error)}
        aria-describedby={describedBy}
        className="sso-field__input"
      />
      {hint ? (
        <div id={hintId} className="sso-field__hint">
          {hint}
        </div>
      ) : null}
      {error ? (
        <div id={errorId} className="sso-field__error" role="alert">
          {error}
        </div>
      ) : null}
    </div>
  );
}

export function PasswordField(props: TextFieldProps) {
  return <TextField {...props} type="password" autoComplete="current-password" />;
}

export function LoadingPage({ message = "Loading…" }: { message?: string }) {
  return (
    <div className="sso-loading" role="status" aria-live="polite">
      <span className="sso-spinner" aria-hidden="true" />
      <span>{message}</span>
    </div>
  );
}

export function Alert({
  type = "error",
  children,
}: {
  type?: "error" | "warning" | "info" | "success";
  children: ReactNode;
}) {
  return (
    <div className={`sso-alert sso-alert--${type}`} role="alert">
      {children}
    </div>
  );
}
