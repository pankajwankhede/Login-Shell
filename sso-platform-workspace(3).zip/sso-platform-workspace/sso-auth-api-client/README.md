# sso-auth-api-client
Shared credentialed Axios client.

```bash
npm install && npm run build
```
