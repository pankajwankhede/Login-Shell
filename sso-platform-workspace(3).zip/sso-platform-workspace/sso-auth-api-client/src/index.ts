import axios,{AxiosInstance} from "axios";
import type {ActionResponse,AuthApi,BootstrapResponse} from "@company/sso-auth-core";
export class SsoApiClient implements AuthApi{
 private c:AxiosInstance; constructor(baseURL="/api/auth"){this.c=axios.create({baseURL,withCredentials:true,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN"});}
 async bootstrap(id:string){await this.c.get("/csrf");return (await this.c.get<BootstrapResponse>(`/bootstrap/${id}`)).data}
 async selectFlow(requestId:string,flow:string){return (await this.c.post<ActionResponse>("/flow/select",null,{params:{requestId,flow}})).data}
 async authenticate(x:unknown){return (await this.c.post<ActionResponse>("/authenticate",x)).data}
 async startForgotPassword(x:unknown){return (await this.c.post<ActionResponse>("/forgot-password/start",x)).data}
 async verifyForgotPassword(x:unknown){return (await this.c.post<ActionResponse>("/forgot-password/verify",x)).data}
 async completeForgotPassword(x:unknown){return (await this.c.post<ActionResponse>("/forgot-password/complete",x)).data}
 async startForgotUsername(x:unknown){return (await this.c.post<ActionResponse>("/forgot-username/start",x)).data}
 async verifyForgotUsername(x:unknown){return (await this.c.post<ActionResponse>("/forgot-username/verify",x)).data}
 async completeForgotUsername(requestId:string){return (await this.c.post<ActionResponse>("/forgot-username/complete",null,{params:{requestId}})).data}
 async updateExpiredPassword(x:unknown){return (await this.c.post<ActionResponse>("/password-expired/update",x)).data}
 async updateProfile(x:unknown){return (await this.c.put<ActionResponse>("/profile",x)).data}
 async startTransmit(requestId:string){return (await this.c.post<ActionResponse>("/transmit/start",null,{params:{requestId}})).data}
 async completeTransmit(x:unknown){return (await this.c.post<ActionResponse>("/transmit/complete",x)).data}
 async completeAuthorization(requestId:string){return (await this.c.post<ActionResponse>("/authorize/complete",null,{params:{requestId}})).data}
 async logout(x:unknown){await this.c.post("/logout",x)}
}
export const ssoApi=new SsoApiClient();
