import type {TransmitAdapter} from '@company/sso-flow-transmit';
export interface ThirdPartyTransmitSdk{initialize(c:Record<string,unknown>):Promise<void>;startJourney(c:Record<string,unknown>):Promise<{status:string}>;destroy?():void}
export class CompanyTransmitAdapter implements TransmitAdapter{constructor(private sdk:ThirdPartyTransmitSdk,private config:Record<string,unknown>){} async start(input:{requestId:string;realm:string}){await this.sdk.initialize(this.config);const r=await this.sdk.startJourney(input);return{success:r.status==='SUCCESS'}} destroy(){this.sdk.destroy?.()}}
export class MockTransmitAdapter implements TransmitAdapter{async start(){return{success:true}} destroy(){}}
