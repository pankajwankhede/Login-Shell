# sso-transmit-sdk-adapter
Isolation adapter for the third-party Transmit SDK.

```bash
npm install && npm run build
```
