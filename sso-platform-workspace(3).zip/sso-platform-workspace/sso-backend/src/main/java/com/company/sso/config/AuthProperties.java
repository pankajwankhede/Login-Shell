package com.company.sso.config;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "auth")
public record AuthProperties(
        Duration requestTtl,
        Duration journeyTtl,
        RememberMeGlobal rememberMe,
        Map<String, RealmProperties> realms) {

    public record RememberMeGlobal(String cookieName, Duration tokenTtl, String secureKey) {}
    public record RealmProperties(
            boolean enabled,
            List<String> allowedClients,
            List<String> allowedRedirectUris,
            List<String> allowFrom,
            SameRealmUserPolicy sameRealmUserPolicy,
            FlowProperties flows,
            SessionPolicy sessionPolicy,
            UiProperties ui,
            ValidationProperties validation,
            Map<String, String> disabledFlowActions) {}
    public enum SameRealmUserPolicy { REUSE_EXISTING, REPLACE_EXISTING, ISOLATE_BY_REQUEST, REJECT_DIFFERENT_USER }
    public record FlowProperties(boolean authenticate, boolean forgotPassword, boolean forgotUsername,
                                 boolean passwordExpired, boolean missingProfile, boolean transmit,
                                 boolean rememberMe) {}
    public record SessionPolicy(SessionMode mode, Duration timeout, boolean slidingExpiration,
                                boolean invalidateAfterAuthentication) {}
    public enum SessionMode { REALM_CONTEXT, TRANSIENT }
    public record UiProperties(LayoutProperties publicLayout, LayoutProperties authenticatedLayout) {}
    public record LayoutProperties(String pageTitle, String faviconUrl, String logoUrl, String logoAlt,
                                   String headerTitle, String footerText, String footerSymbol,
                                   List<LinkProperties> headerLinks, List<LinkProperties> footerLinks,
                                   List<String> approvedScriptIds) {}
    public record LinkProperties(String id, String label, String url, String target, String icon) {}
    public record ValidationProperties(TextRule username, PasswordRule password,
                                       TextRule email, TextRule phone) {}
    public record TextRule(boolean required, Integer minLength, Integer maxLength, String pattern,
                           boolean trim, Map<String, String> messages) {}
    public record PasswordRule(boolean required, Integer minLength, Integer maxLength,
                               boolean requireUppercase, boolean requireLowercase,
                               boolean requireNumber, boolean requireSpecialCharacter,
                               String allowedSpecialCharacters, boolean disallowSpaces,
                               boolean preventUsernameInPassword, Integer passwordHistoryCount,
                               Map<String, String> messages) {}
}
