package com.company.sso.clientlog;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.stereotype.Component;

@Component
public class ClientLogRateLimiter {
    private record Window(Instant startedAt, AtomicInteger count) {}
    private final ConcurrentHashMap<String, Window> windows = new ConcurrentHashMap<>();
    private final ClientLogProperties properties;

    public ClientLogRateLimiter(ClientLogProperties properties) { this.properties = properties; }

    public boolean allow(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        String key = session != null ? "S:" + session.getId() : "I:" + request.getRemoteAddr();
        Instant now = Instant.now();
        Window window = windows.compute(key, (ignored, current) -> {
            if (current == null || current.startedAt().plus(properties.rateLimitWindow()).isBefore(now)) return new Window(now, new AtomicInteger(1));
            current.count().incrementAndGet();
            return current;
        });
        return window.count().get() <= properties.maxBatchesPerWindow();
    }
}
