package com.company.sso.realm;

import com.company.sso.config.AuthProperties;
import com.company.sso.config.AuthProperties.RealmProperties;
import com.company.sso.domain.Models.Flow;
import com.company.sso.error.SsoExceptions.*;
import java.net.URI;
import java.util.Locale;
import org.springframework.stereotype.Service;

@Service
public class RealmPolicyService {
    private final AuthProperties properties;
    public RealmPolicyService(AuthProperties properties){ this.properties = properties; }
    public RealmProperties realm(String realm){
        RealmProperties value = properties.realms().get(normalize(realm));
        if(value == null || !value.enabled()) throw new NotFound("REALM_NOT_FOUND", "Unknown or disabled realm.");
        return value;
    }
    public void validateClient(String realm, String clientId, String redirectUri){
        RealmProperties rp = realm(realm);
        if(!rp.allowedClients().contains(clientId)) throw new Forbidden("CLIENT_NOT_ALLOWED", "Client is not allowed for this realm.");
        URI requested;
        try { requested = URI.create(redirectUri); } catch(Exception e){ throw new Forbidden("INVALID_REDIRECT_URI", "Invalid redirect URI."); }
        boolean allowed = rp.allowedRedirectUris().stream().map(URI::create)
                .anyMatch(x -> x.equals(requested));
        if(!allowed) throw new Forbidden("REDIRECT_URI_NOT_ALLOWED", "Redirect URI is not registered.");
    }
    public boolean enabled(String realm, Flow flow){
        var f = realm(realm).flows();
        return switch(flow){
            case AUTHENTICATE -> f.authenticate(); case FORGOT_PASSWORD -> f.forgotPassword();
            case FORGOT_USERNAME -> f.forgotUsername(); case PASSWORD_EXPIRED -> f.passwordExpired();
            case MISSING_PROFILE -> f.missingProfile(); case TRANSMIT -> f.transmit(); case COMPLETE -> true;
        };
    }
    public void requireEnabled(String realm, Flow flow){
        if(!enabled(realm, flow)) throw new Forbidden("FLOW_DISABLED_FOR_REALM", flow + " is disabled for realm " + realm + ".");
    }
    public boolean canReuse(String sourceRealm, String targetRealm){
        return normalize(sourceRealm).equals(normalize(targetRealm)) || realm(targetRealm).allowFrom().contains(normalize(sourceRealm));
    }
    public AuthProperties properties(){ return properties; }
    public String normalize(String value){ return value == null ? "" : value.trim().toUpperCase(Locale.ROOT); }
}
