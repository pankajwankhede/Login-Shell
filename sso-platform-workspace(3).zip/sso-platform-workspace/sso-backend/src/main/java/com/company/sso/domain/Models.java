package com.company.sso.domain;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;
import java.util.Set;

public final class Models {
    private Models() {}

    public enum Flow {
        AUTHENTICATE, FORGOT_PASSWORD, FORGOT_USERNAME,
        PASSWORD_EXPIRED, MISSING_PROFILE, TRANSMIT, COMPLETE
    }

    public enum JourneyStatus { STARTED, CHALLENGE_SENT, VERIFIED, COMPLETED, FAILED }

    public record SsoRequest(
            String requestId, String clientId, String realm, String redirectUri,
            String state, String scope, String responseType,
            Instant createdAt, Instant expiresAt) implements Serializable {}

    public record RealmUserContext(
            String realm, String userId, String username, String displayName,
            Set<String> roles, boolean profileComplete, boolean passwordExpired,
            boolean rememberMeRestored, Instant authenticatedAt,
            Instant lastAccessedAt, Instant expiresAt) implements Serializable {}

    public record RequestUserContext(
            String requestId, String realm, String userId, String username,
            String displayName, Set<String> roles, String userReference,
            boolean profileComplete, boolean passwordExpired,
            Instant createdAt, Instant expiresAt) implements Serializable {}

    public record Journey(
            String requestId, String realm, Flow nextAction, JourneyStatus status,
            String userReference, String challengeId, String transmitJourneyId,
            Map<String, String> metadata, Instant createdAt,
            Instant updatedAt, Instant expiresAt) implements Serializable {}

    public record ExternalUser(
            String userId, String username, String displayName, Set<String> roles,
            boolean passwordExpired, boolean profileMissing, boolean transmitRequired,
            boolean active, String userReference, Map<String, String> profile) {}

    public record RecoveryStartResult(String challengeId, String maskedDestination) {}
    public record RecoveryVerifyResult(boolean verified, String userReference) {}
    public record TransmitStartResult(String journeyId, Map<String, String> sdkConfig) {}
    public record TransmitCompleteResult(boolean verified) {}
}
