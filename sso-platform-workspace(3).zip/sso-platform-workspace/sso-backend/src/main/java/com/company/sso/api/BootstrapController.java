package com.company.sso.api;

import com.company.sso.api.ApiModels.*;
import com.company.sso.domain.Models.*;
import com.company.sso.realm.RealmPolicyService;
import com.company.sso.service.SsoService;
import jakarta.servlet.http.*;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class BootstrapController {
    private final SsoService service; private final RealmPolicyService policy;
    public BootstrapController(SsoService s,RealmPolicyService p){service=s;policy=p;}
    @GetMapping("/bootstrap/{id}")
    public BootstrapResponse bootstrap(@PathVariable String id,HttpServletRequest req,HttpServletResponse res){
        HttpSession session=req.getSession(false); SsoRequest r=service.requiredRequest(session,id); Flow f=service.bootstrap(req,res,r); var rp=policy.realm(r.realm());
        boolean authenticated=f!=Flow.AUTHENTICATE&&f!=Flow.FORGOT_PASSWORD&&f!=Flow.FORGOT_USERNAME;
        var ui=authenticated?rp.ui().authenticatedLayout():rp.ui().publicLayout();
        var user=service.requestUser(session,id).map(x->new UserSummary(x.displayName(),x.realm())).orElse(null);
        return new BootstrapResponse(id,r.realm(),r.clientId(),authenticated,f.name(),authenticated?"AUTHENTICATED_JOURNEY":"PUBLIC",rp.flows(),ui,rp.validation(),rp.sessionPolicy(),user);
    }
    @GetMapping("/csrf") public java.util.Map<String,String> csrf(org.springframework.security.web.csrf.CsrfToken token){return java.util.Map.of("headerName",token.getHeaderName(),"token",token.getToken());}
}
