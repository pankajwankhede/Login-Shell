package com.company.sso.api;

import com.company.sso.api.ApiModels.*;
import com.company.sso.domain.Models.Flow;
import com.company.sso.service.*;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class RecoveryController {
    private final RecoveryService recovery; private final SsoService sso; private final ValidationService validation;
    public RecoveryController(RecoveryService r,SsoService s,ValidationService v){recovery=r;sso=s;validation=v;}
    @PostMapping("/forgot-password/start") public ActionResponse startPassword(@RequestBody RecoveryStartRequest b,HttpServletRequest req){var r=sso.requiredRequest(req.getSession(false),b.requestId());String u=validation.username(r.realm(),b.username());var x=recovery.startPassword(req.getSession(false),b.requestId(),u);return new ActionResponse(b.requestId(),Flow.FORGOT_PASSWORD.name(),null,Map.of("maskedDestination",x.maskedDestination()));}
    @PostMapping("/forgot-password/verify") public ActionResponse verifyPassword(@RequestBody RecoveryVerifyRequest b,HttpServletRequest req){recovery.verifyPassword(req.getSession(false),b.requestId(),b.verificationCode());return ActionResponse.next(b.requestId(),Flow.FORGOT_PASSWORD.name());}
    @PostMapping("/forgot-password/complete") public ActionResponse completePassword(@RequestBody ForgotPasswordCompleteRequest b,HttpServletRequest req){var r=sso.requiredRequest(req.getSession(false),b.requestId());validation.password(r.realm(),null,b.newPassword(),b.confirmPassword());recovery.completePassword(req.getSession(false),b.requestId(),b.newPassword());return ActionResponse.next(b.requestId(),Flow.AUTHENTICATE.name());}
    @PostMapping("/forgot-username/start") public ActionResponse startUsername(@RequestBody RecoveryStartRequest b,HttpServletRequest req){var r=sso.requiredRequest(req.getSession(false),b.requestId());Map<String,String> data=Map.of("email",b.email()==null?"":b.email(),"phone",b.phone()==null?"":b.phone());var x=recovery.startUsername(req.getSession(false),b.requestId(),data);return new ActionResponse(b.requestId(),Flow.FORGOT_USERNAME.name(),null,Map.of("maskedDestination",x.maskedDestination()));}
    @PostMapping("/forgot-username/verify") public ActionResponse verifyUsername(@RequestBody RecoveryVerifyRequest b,HttpServletRequest req){recovery.verifyUsername(req.getSession(false),b.requestId(),b.verificationCode());return ActionResponse.next(b.requestId(),Flow.FORGOT_USERNAME.name());}
    @PostMapping("/forgot-username/complete") public ActionResponse completeUsername(@RequestParam String requestId,HttpServletRequest req){String username=recovery.completeUsername(req.getSession(false),requestId);return new ActionResponse(requestId,Flow.AUTHENTICATE.name(),null,Map.of("username",username));}
}
