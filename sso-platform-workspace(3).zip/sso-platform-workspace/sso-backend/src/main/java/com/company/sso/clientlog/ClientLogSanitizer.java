package com.company.sso.clientlog;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;

@Component
public class ClientLogSanitizer {
    private static final Pattern BLOCKED = Pattern.compile("password|passwd|pwd|otp|token|secret|authorization|cookie|session(id)?|ssn|account(number)?|card(number)?|cvv|pin", Pattern.CASE_INSENSITIVE);
    private static final Set<Class<?>> PRIMITIVES = Set.of(String.class, Boolean.class, Integer.class, Long.class, Double.class, Float.class, Short.class, Byte.class);
    private final ClientLogProperties properties;

    public ClientLogSanitizer(ClientLogProperties properties) { this.properties = properties; }

    public String sanitizeMessage(String value) {
        if (value == null) return null;
        return truncate(value.replaceAll("[\\r\\n\\t]+", " ").trim(), properties.maxMessageLength());
    }

    public Map<String, Object> sanitizeMetadata(Map<String, Object> metadata) {
        if (metadata == null || metadata.isEmpty()) return Map.of();
        Map<String, Object> safe = new LinkedHashMap<>();
        metadata.forEach((key, value) -> {
            if (key == null || BLOCKED.matcher(key.toLowerCase(Locale.ROOT)).find() || value == null) return;
            if (!PRIMITIVES.contains(value.getClass())) return;
            safe.put(truncate(key, 80), value instanceof String s ? truncate(s.replaceAll("[\\r\\n\\t]+", " "), properties.maxMetadataValueLength()) : value);
        });
        return Map.copyOf(safe);
    }

    private String truncate(String value, int max) { return value.length() <= max ? value : value.substring(0, max); }
}
