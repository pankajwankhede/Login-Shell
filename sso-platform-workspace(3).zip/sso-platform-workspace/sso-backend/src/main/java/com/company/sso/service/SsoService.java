package com.company.sso.service;

import com.company.sso.api.ApiModels.ActionResponse;
import com.company.sso.config.AuthProperties.*;
import com.company.sso.domain.Models.*;
import com.company.sso.error.SsoExceptions.*;
import com.company.sso.external.ExternalLoginClient;
import com.company.sso.realm.RealmPolicyService;
import com.company.sso.remember.RememberMeManager;
import com.company.sso.session.SessionStateRepository;
import jakarta.servlet.http.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class SsoService {
    private final SessionStateRepository repo; private final RealmPolicyService policy;
    private final ExternalLoginClient login; private final RememberMeManager remember;
    public SsoService(SessionStateRepository r,RealmPolicyService p,ExternalLoginClient l,RememberMeManager remember){this.repo=r;this.policy=p;this.login=l;this.remember=remember;}

    public SsoRequest start(HttpServletRequest req,String client,String redirect,String realm,String state,String scope,String responseType){
        realm=policy.normalize(realm); policy.validateClient(realm,client,redirect); HttpSession s=req.getSession(true); repo.cleanupExpired(s);
        String id=UUID.randomUUID().toString(); Instant now=Instant.now(); SsoRequest r=new SsoRequest(id,client,realm,redirect,state,scope,responseType==null?"code":responseType,now,now.plus(policy.properties().requestTtl()));repo.saveRequest(s,r);return r;
    }
    public Flow bootstrap(HttpServletRequest request,HttpServletResponse response,SsoRequest r){
        HttpSession s=request.getSession(false); repo.cleanupExpired(s);
        Optional<Journey> activeJourney=repo.journey(s,r.requestId());
        if(activeJourney.isPresent() && activeJourney.get().expiresAt().isAfter(Instant.now()) && activeJourney.get().nextAction()!=Flow.COMPLETE) return activeJourney.get().nextAction();
        Optional<RequestUserContext> requestUser=repo.requestUser(s,r.requestId()); if(requestUser.isPresent())return nextFor(requestUser.get());
        Optional<RealmUserContext> exact=validRealmUser(s,r.realm());
        if(exact.isEmpty()) exact=reuseFromAllowedRealm(s,r);
        if(exact.isEmpty()&&policy.realm(r.realm()).flows().rememberMe()){
            Optional<ExternalUser> restored=remember.restore(r.realm(),request,response); if(restored.isPresent()) exact=Optional.of(saveAuthenticated(s,r,restored.get(),true));
        }
        if(exact.isEmpty()) return Flow.AUTHENTICATE;
        RealmUserContext user=touch(s,exact.get()); bindRequestUser(s,r,user,null); return nextFor(user);
    }
    public Flow authenticate(HttpServletRequest req,HttpServletResponse response,String requestId,String username,String password,boolean rememberRequested){
        HttpSession s=req.getSession(false); SsoRequest r=requiredRequest(s,requestId); ExternalUser u;
        try{u=login.authenticate(r.realm(),username,password);}catch(Exception e){throw new Unauthorized("INVALID_CREDENTIALS","The username or password is incorrect.");}
        if(!u.active())throw new Forbidden("ACCOUNT_DISABLED","Account is disabled.");
        if(s!=null) req.changeSessionId(); RealmUserContext realmUser=saveAuthenticated(s,r,u,false); bindRequestUser(s,r,realmUser,u.userReference());
        Flow next=nextFor(u,r.realm()); policy.requireEnabled(r.realm(),next);
        repo.saveJourney(s,newJourney(r,next,u.userReference()));
        if(rememberRequested&&policy.realm(r.realm()).flows().rememberMe()) remember.issue(r.realm(),u,response);
        if(policy.realm(r.realm()).sessionPolicy().mode()==SessionMode.TRANSIENT && next==Flow.COMPLETE) return Flow.COMPLETE;
        return next;
    }
    public ActionResponse completeAuthorization(HttpSession s,String requestId){
        SsoRequest r=requiredRequest(s,requestId); String code="CODE-"+UUID.randomUUID();
        String sep=r.redirectUri().contains("?")?"&":"?"; String url=r.redirectUri()+sep+"code="+enc(code)+(r.state()==null?"":"&state="+enc(r.state()));
        boolean transientRealm=policy.realm(r.realm()).sessionPolicy().mode()==SessionMode.TRANSIENT;
        repo.cleanupRequest(s,requestId); if(transientRealm)repo.removeRealmUser(s,r.realm());
        return new ActionResponse(requestId,Flow.COMPLETE.name(),url,Map.of("authorizationCode",code));
    }
    public Journey beginJourney(HttpSession s,String requestId,Flow flow){SsoRequest r=requiredRequest(s,requestId);policy.requireEnabled(r.realm(),flow);Journey j=newJourney(r,flow,null);repo.saveJourney(s,j);return j;}
    public Journey updateJourney(HttpSession s,Journey old,Flow next,JourneyStatus status,String userRef,String challenge,String transmit,Map<String,String> meta){Journey j=new Journey(old.requestId(),old.realm(),next,status,userRef,challenge,transmit,meta,old.createdAt(),Instant.now(),old.expiresAt());repo.saveJourney(s,j);return j;}
    public SsoRequest requiredRequest(HttpSession s,String id){if(s==null)throw new Unauthorized("SESSION_NOT_FOUND","Session is not available.");SsoRequest r=repo.request(s,id).orElseThrow(()->new NotFound("REQUEST_NOT_FOUND","SSO request was not found."));if(!r.expiresAt().isAfter(Instant.now())){repo.cleanupRequest(s,id);throw new Unauthorized("REQUEST_EXPIRED","SSO request has expired.");}return r;}
    public Journey requiredJourney(HttpSession s,String id,Flow flow){Journey j=repo.journey(s,id).orElseThrow(()->new NotFound("JOURNEY_NOT_FOUND","Authentication journey was not found."));if(!j.expiresAt().isAfter(Instant.now())){repo.cleanupRequest(s,id);throw new Unauthorized("JOURNEY_EXPIRED","Authentication journey has expired.");}if(j.nextAction()!=flow)throw new Conflict("INVALID_JOURNEY_STATE","Current journey does not allow this operation.");return j;}
    public Optional<RealmUserContext> validRealmUser(HttpSession s,String realm){Optional<RealmUserContext> u=repo.realmUser(s,realm);if(u.isPresent()&&!u.get().expiresAt().isAfter(Instant.now())){repo.removeRealmUser(s,realm);return Optional.empty();}return u;}
    public Optional<RequestUserContext> requestUser(HttpSession s,String id){return repo.requestUser(s,id);}
    public void logout(HttpSession s,String requestId,String realm,boolean global){if(s==null)return;if(global){s.invalidate();return;}String resolved=realm;if((resolved==null||resolved.isBlank())&&requestId!=null)resolved=requiredRequest(s,requestId).realm();if(resolved!=null)repo.removeRealmUser(s,policy.normalize(resolved));if(requestId!=null)repo.cleanupRequest(s,requestId);if(repo.empty(s))s.invalidate();}
    public void revokeRemember(HttpServletRequest request,HttpServletResponse response){remember.revokeCurrent(request,response);}
    private RealmUserContext saveAuthenticated(HttpSession s,SsoRequest r,ExternalUser u,boolean restored){
        SessionPolicy sp=policy.realm(r.realm()).sessionPolicy();Instant now=Instant.now();RealmUserContext ctx=new RealmUserContext(r.realm(),u.userId(),u.username(),u.displayName(),u.roles(),!u.profileMissing(),u.passwordExpired(),restored,now,now,now.plus(sp.timeout()));
        if(sp.mode()==SessionMode.REALM_CONTEXT) repo.saveRealmUser(s,r.realm(),ctx); return ctx;
    }
    private void bindRequestUser(HttpSession s,SsoRequest r,RealmUserContext u,String userRef){repo.saveRequestUser(s,new RequestUserContext(r.requestId(),r.realm(),u.userId(),u.username(),u.displayName(),u.roles(),userRef,u.profileComplete(),u.passwordExpired(),Instant.now(),r.expiresAt()));}
    private Optional<RealmUserContext> reuseFromAllowedRealm(HttpSession s,SsoRequest r){for(var e:repo.realmUsers(s).entrySet()){if(policy.canReuse(e.getKey(),r.realm())&&e.getValue().expiresAt().isAfter(Instant.now())){ExternalUser refreshed=login.refresh(r.realm(),e.getValue().userId());return Optional.of(saveAuthenticated(s,r,refreshed,false));}}return Optional.empty();}
    private RealmUserContext touch(HttpSession s,RealmUserContext u){SessionPolicy sp=policy.realm(u.realm()).sessionPolicy();if(!sp.slidingExpiration())return u;Instant now=Instant.now();RealmUserContext x=new RealmUserContext(u.realm(),u.userId(),u.username(),u.displayName(),u.roles(),u.profileComplete(),u.passwordExpired(),u.rememberMeRestored(),u.authenticatedAt(),now,now.plus(sp.timeout()));repo.saveRealmUser(s,u.realm(),x);return x;}
    private Flow nextFor(RealmUserContext u){if(u.passwordExpired())return Flow.PASSWORD_EXPIRED;if(!u.profileComplete())return Flow.MISSING_PROFILE;return Flow.COMPLETE;}
    private Flow nextFor(RequestUserContext u){if(u.passwordExpired())return Flow.PASSWORD_EXPIRED;if(!u.profileComplete())return Flow.MISSING_PROFILE;return Flow.COMPLETE;}
    private Flow nextFor(ExternalUser u,String realm){if(u.passwordExpired())return Flow.PASSWORD_EXPIRED;if(u.profileMissing())return Flow.MISSING_PROFILE;if(u.transmitRequired())return Flow.TRANSMIT;return Flow.COMPLETE;}
    private Journey newJourney(SsoRequest r,Flow flow,String ref){Instant now=Instant.now();return new Journey(r.requestId(),r.realm(),flow,JourneyStatus.STARTED,ref,null,null,Map.of(),now,now,now.plus(policy.properties().journeyTtl()));}
    private String enc(String x){return URLEncoder.encode(x,StandardCharsets.UTF_8);}
}
