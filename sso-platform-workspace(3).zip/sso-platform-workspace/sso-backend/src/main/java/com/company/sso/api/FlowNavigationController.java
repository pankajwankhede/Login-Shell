package com.company.sso.api;

import com.company.sso.api.ApiModels.ActionResponse;
import com.company.sso.domain.Models.Flow;
import com.company.sso.service.SsoService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth/flow")
public class FlowNavigationController {
    private final SsoService sso;
    public FlowNavigationController(SsoService sso){this.sso=sso;}
    @PostMapping("/select")
    public ActionResponse select(@RequestParam String requestId,@RequestParam Flow flow,HttpServletRequest request){
        sso.beginJourney(request.getSession(false),requestId,flow);
        return ActionResponse.next(requestId,flow.name());
    }
}
