package com.company.sso.external;

import com.company.sso.domain.Models.*;
import java.util.Map;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
@ConditionalOnProperty(prefix="external-login", name="mock-enabled", havingValue="false")
public class RemoteExternalLoginClient implements ExternalLoginClient {
    private final WebClient client;
    public RemoteExternalLoginClient(WebClient.Builder builder, ExternalLoginProperties p){this.client=builder.baseUrl(p.baseUrl()).build();}
    public ExternalUser authenticate(String realm,String username,String password){return post("/authenticate",Map.of("realm",realm,"username",username,"password",password),ExternalUser.class);}
    public ExternalUser refresh(String realm,String ref){return post("/user/refresh",Map.of("realm",realm,"userReference",ref),ExternalUser.class);}
    public RecoveryStartResult startForgotPassword(String realm,String username){return post("/forgot-password/start",Map.of("realm",realm,"username",username),RecoveryStartResult.class);}
    public RecoveryVerifyResult verifyForgotPassword(String realm,String c,String code){return post("/forgot-password/verify",Map.of("realm",realm,"challengeId",c,"code",code),RecoveryVerifyResult.class);}
    public void completeForgotPassword(String realm,String ref,String pwd){post("/forgot-password/complete",Map.of("realm",realm,"userReference",ref,"newPassword",pwd),Void.class);}
    public RecoveryStartResult startForgotUsername(String realm,Map<String,String> data){return post("/forgot-username/start",Map.of("realm",realm,"identityData",data),RecoveryStartResult.class);}
    public RecoveryVerifyResult verifyForgotUsername(String realm,String c,String code){return post("/forgot-username/verify",Map.of("realm",realm,"challengeId",c,"code",code),RecoveryVerifyResult.class);}
    public String completeForgotUsername(String realm,String ref){return post("/forgot-username/complete",Map.of("realm",realm,"userReference",ref),String.class);}
    public void updateExpiredPassword(String realm,String ref,String pwd){post("/password-expired/update",Map.of("realm",realm,"userReference",ref,"newPassword",pwd),Void.class);}
    public ExternalUser updateProfile(String realm,String ref,Map<String,String> profile){return post("/profile/update",Map.of("realm",realm,"userReference",ref,"profile",profile),ExternalUser.class);}
    public TransmitStartResult startTransmit(String realm,String ref){return post("/transmit/start",Map.of("realm",realm,"userReference",ref),TransmitStartResult.class);}
    public TransmitCompleteResult completeTransmit(String realm,String id,String result){return post("/transmit/complete",Map.of("realm",realm,"journeyId",id,"resultReference",result),TransmitCompleteResult.class);}
    private <T>T post(String uri,Object body,Class<T> type){return client.post().uri(uri).bodyValue(body).retrieve().bodyToMono(type).block();}
}
