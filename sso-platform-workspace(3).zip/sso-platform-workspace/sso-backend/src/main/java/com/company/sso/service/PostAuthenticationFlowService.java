package com.company.sso.service;

import com.company.sso.domain.Models.*;
import com.company.sso.external.ExternalLoginClient;
import com.company.sso.session.SessionStateRepository;
import jakarta.servlet.http.HttpSession;
import java.time.Instant;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class PostAuthenticationFlowService {
    private final SsoService sso; private final ExternalLoginClient login; private final SessionStateRepository repo;
    public PostAuthenticationFlowService(SsoService sso,ExternalLoginClient login,SessionStateRepository repo){this.sso=sso;this.login=login;this.repo=repo;}
    public void updateExpiredPassword(HttpSession session,String id,String password){Journey j=sso.requiredJourney(session,id,Flow.PASSWORD_EXPIRED);login.updateExpiredPassword(j.realm(),j.userReference(),password);RequestUserContext u=sso.requestUser(session,id).orElseThrow();repo.saveRequestUser(session,new RequestUserContext(u.requestId(),u.realm(),u.userId(),u.username(),u.displayName(),u.roles(),u.userReference(),u.profileComplete(),false,u.createdAt(),u.expiresAt()));repo.saveJourney(session,new Journey(id,j.realm(),Flow.COMPLETE,JourneyStatus.COMPLETED,j.userReference(),null,null,Map.of(),j.createdAt(),Instant.now(),j.expiresAt()));}
    public void updateProfile(HttpSession session,String id,Map<String,String> profile){Journey j=sso.requiredJourney(session,id,Flow.MISSING_PROFILE);ExternalUser updated=login.updateProfile(j.realm(),j.userReference(),profile);RequestUserContext u=sso.requestUser(session,id).orElseThrow();repo.saveRequestUser(session,new RequestUserContext(u.requestId(),u.realm(),u.userId(),u.username(),updated.displayName(),updated.roles(),u.userReference(),true,u.passwordExpired(),u.createdAt(),u.expiresAt()));repo.saveJourney(session,new Journey(id,j.realm(),Flow.COMPLETE,JourneyStatus.COMPLETED,j.userReference(),null,null,profile,j.createdAt(),Instant.now(),j.expiresAt()));}
    public TransmitStartResult startTransmit(HttpSession session,String id){Journey j=sso.requiredJourney(session,id,Flow.TRANSMIT);TransmitStartResult result=login.startTransmit(j.realm(),j.userReference());sso.updateJourney(session,j,Flow.TRANSMIT,JourneyStatus.STARTED,j.userReference(),null,result.journeyId(),Map.of());return result;}
    public void completeTransmit(HttpSession session,String id,String resultRef){Journey j=sso.requiredJourney(session,id,Flow.TRANSMIT);var result=login.completeTransmit(j.realm(),j.transmitJourneyId(),resultRef);if(!result.verified())throw new IllegalArgumentException("TRANSMIT_VERIFICATION_FAILED");repo.saveJourney(session,new Journey(id,j.realm(),Flow.COMPLETE,JourneyStatus.COMPLETED,j.userReference(),null,j.transmitJourneyId(),Map.of(),j.createdAt(),Instant.now(),j.expiresAt()));}
}
