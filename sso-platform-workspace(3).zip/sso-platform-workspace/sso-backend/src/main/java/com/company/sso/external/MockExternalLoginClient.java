package com.company.sso.external;

import com.company.sso.domain.Models.*;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix="external-login", name="mock-enabled", havingValue="true")
public class MockExternalLoginClient implements ExternalLoginClient {
    public ExternalUser authenticate(String realm,String username,String password){
        if(username==null||password==null||password.isBlank()||"bad".equals(password)) throw new IllegalArgumentException("INVALID_CREDENTIALS");
        String x=username.toLowerCase();
        return new ExternalUser(realm+"-"+Math.abs(username.hashCode()),username,"Demo "+username,
                Set.of(realm+"_USER"),x.contains("expired"),x.contains("missing"),x.contains("transmit"),true,
                "REF-"+realm+"-"+username,Map.of("email",username+"@example.com"));
    }
    public ExternalUser refresh(String realm,String ref){return new ExternalUser(realm+"-100",ref,"Restored User",Set.of(realm+"_USER"),false,false,false,true,ref,Map.of());}
    public RecoveryStartResult startForgotPassword(String realm,String username){return new RecoveryStartResult("PWD-"+UUID.randomUUID(),"***-***-1234");}
    public RecoveryVerifyResult verifyForgotPassword(String realm,String challengeId,String code){return new RecoveryVerifyResult("123456".equals(code),"REF-RECOVERY");}
    public void completeForgotPassword(String realm,String userReference,String newPassword){}
    public RecoveryStartResult startForgotUsername(String realm,Map<String,String> identityData){return new RecoveryStartResult("USR-"+UUID.randomUUID(),"m***@example.com");}
    public RecoveryVerifyResult verifyForgotUsername(String realm,String challengeId,String code){return new RecoveryVerifyResult("123456".equals(code),"REF-USERNAME");}
    public String completeForgotUsername(String realm,String userReference){return "demo.user";}
    public void updateExpiredPassword(String realm,String userReference,String newPassword){}
    public ExternalUser updateProfile(String realm,String userReference,Map<String,String> profile){return new ExternalUser(realm+"-100","updated.user","Updated User",Set.of(realm+"_USER"),false,false,false,true,userReference,profile);}
    public TransmitStartResult startTransmit(String realm,String userReference){return new TransmitStartResult("TX-"+UUID.randomUUID(),Map.of("mock","true"));}
    public TransmitCompleteResult completeTransmit(String realm,String journeyId,String resultReference){return new TransmitCompleteResult(resultReference!=null&&!resultReference.isBlank());}
}
