package com.company.sso.remember;

import com.company.sso.config.AuthProperties;
import com.company.sso.domain.Models.ExternalUser;
import com.company.sso.external.ExternalLoginClient;
import jakarta.servlet.http.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;

@Service
public class DefaultRememberMeManager implements RememberMeManager {
    private final RememberTokenRepository repo; private final ExternalLoginClient login; private final AuthProperties properties;
    public DefaultRememberMeManager(RememberTokenRepository repo,ExternalLoginClient login,AuthProperties p){this.repo=repo;this.login=login;this.properties=p;}
    public void issue(String realm,ExternalUser user,HttpServletResponse response){
        String series=UUID.randomUUID().toString(), raw=random(); Instant expiry=Instant.now().plus(properties.rememberMe().tokenTtl());
        repo.save(new RememberTokenRepository.TokenRecord(series,hash(raw),realm,user.userId(),user.userReference(),expiry,false));
        write(response,Base64.getUrlEncoder().withoutPadding().encodeToString((series+":"+raw).getBytes(StandardCharsets.UTF_8)),properties.rememberMe().tokenTtl().toSeconds());
    }
    public Optional<ExternalUser> restore(String realm,HttpServletRequest request,HttpServletResponse response){
        String value=cookie(request); if(value==null)return Optional.empty();
        try{
            String decoded=new String(Base64.getUrlDecoder().decode(value),StandardCharsets.UTF_8); String[] p=decoded.split(":",2);
            var record=repo.find(p[0]).orElse(null);
            if(record==null||record.revoked()||!record.realm().equals(realm)||!record.expiresAt().isAfter(Instant.now())||!MessageDigest.isEqual(record.tokenHash().getBytes(),hash(p[1]).getBytes())){revokeCurrent(request,response);return Optional.empty();}
            ExternalUser user=login.refresh(realm,record.userReference()); if(!user.active()){revokeCurrent(request,response);return Optional.empty();}
            repo.revoke(record.seriesId()); issue(realm,user,response); return Optional.of(user);
        }catch(Exception e){revokeCurrent(request,response);return Optional.empty();}
    }
    public void revokeCurrent(HttpServletRequest request,HttpServletResponse response){String v=cookie(request);if(v!=null)try{String d=new String(Base64.getUrlDecoder().decode(v));repo.revoke(d.split(":",2)[0]);}catch(Exception ignored){} write(response,"",0);}
    public void revokeAll(String realm,String userId){repo.revokeAll(realm,userId);}
    private String cookie(HttpServletRequest req){if(req.getCookies()==null)return null;return Arrays.stream(req.getCookies()).filter(c->properties.rememberMe().cookieName().equals(c.getName())).map(Cookie::getValue).findFirst().orElse(null);}
    private void write(HttpServletResponse response,String value,long seconds){ResponseCookie c=ResponseCookie.from(properties.rememberMe().cookieName(),value).httpOnly(true).secure(true).sameSite("Lax").path("/").maxAge(seconds).build();response.addHeader(HttpHeaders.SET_COOKIE,c.toString());}
    private String random(){byte[] b=new byte[32];new java.security.SecureRandom().nextBytes(b);return Base64.getUrlEncoder().withoutPadding().encodeToString(b);} private String hash(String v){try{return Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest((v+properties.rememberMe().secureKey()).getBytes(StandardCharsets.UTF_8)));}catch(Exception e){throw new IllegalStateException(e);}}
}
