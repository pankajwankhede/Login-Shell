package com.company.sso.service;

import com.company.sso.config.AuthProperties.*;
import com.company.sso.error.SsoExceptions.Validation;
import com.company.sso.realm.RealmPolicyService;
import java.util.*;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;

@Service
public class ValidationService {
    private final RealmPolicyService policy; public ValidationService(RealmPolicyService p){policy=p;}
    public String username(String realm,String value){return text("username",value,policy.realm(realm).validation().username());}
    public String email(String realm,String value){return text("email",value,policy.realm(realm).validation().email());}
    public String phone(String realm,String value){return text("phone",value,policy.realm(realm).validation().phone());}
    public void password(String realm,String username,String value,String confirm){
        PasswordRule r=policy.realm(realm).validation().password();
        if(r.required()&&(value==null||value.isBlank()))fail("newPassword","REQUIRED",msg(r.messages(),"required","Password is required."));
        if(value==null)return;
        if(r.minLength()!=null&&value.length()<r.minLength())fail("newPassword","MIN_LENGTH",msg(r.messages(),"minLength","Password is too short."));
        if(r.maxLength()!=null&&value.length()>r.maxLength())fail("newPassword","MAX_LENGTH",msg(r.messages(),"maxLength","Password is too long."));
        if(r.requireUppercase()&&value.chars().noneMatch(Character::isUpperCase))fail("newPassword","UPPERCASE",msg(r.messages(),"uppercase","Uppercase character required."));
        if(r.requireLowercase()&&value.chars().noneMatch(Character::isLowerCase))fail("newPassword","LOWERCASE",msg(r.messages(),"lowercase","Lowercase character required."));
        if(r.requireNumber()&&value.chars().noneMatch(Character::isDigit))fail("newPassword","NUMBER",msg(r.messages(),"number","Number required."));
        if(r.requireSpecialCharacter()&&(r.allowedSpecialCharacters()==null||r.allowedSpecialCharacters().chars().noneMatch(c->value.indexOf(c)>=0)))fail("newPassword","SPECIAL_CHARACTER",msg(r.messages(),"specialCharacter","Special character required."));
        if(r.disallowSpaces()&&value.chars().anyMatch(Character::isWhitespace))fail("newPassword","SPACES",msg(r.messages(),"spaces","Spaces are not allowed."));
        if(r.preventUsernameInPassword()&&username!=null&&value.toLowerCase(Locale.ROOT).contains(username.toLowerCase(Locale.ROOT)))fail("newPassword","USERNAME_MATCH",msg(r.messages(),"usernameMatch","Password cannot contain username."));
        if(!Objects.equals(value,confirm))fail("confirmPassword","MISMATCH",msg(r.messages(),"mismatch","Passwords do not match."));
    }
    private String text(String field,String value,TextRule r){if(r==null)return value;String v=r.trim()&&value!=null?value.trim():value;if(r.required()&&(v==null||v.isBlank()))fail(field,"REQUIRED",msg(r.messages(),"required","Value is required."));if(v==null)return null;if(r.minLength()!=null&&v.length()<r.minLength())fail(field,"MIN_LENGTH",msg(r.messages(),"minLength","Value is too short."));if(r.maxLength()!=null&&v.length()>r.maxLength())fail(field,"MAX_LENGTH",msg(r.messages(),"maxLength","Value is too long."));if(r.pattern()!=null&&!Pattern.matches(r.pattern(),v))fail(field,"PATTERN",msg(r.messages(),"pattern","Invalid format."));return v;}
    private String msg(Map<String,String> m,String k,String d){return m==null?d:m.getOrDefault(k,d);} private void fail(String f,String r,String m){throw new Validation(f,r,m);}
}
