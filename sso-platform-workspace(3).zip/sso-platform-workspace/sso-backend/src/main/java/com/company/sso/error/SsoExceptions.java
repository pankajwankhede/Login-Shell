package com.company.sso.error;

public final class SsoExceptions {
    private SsoExceptions() {}
    public static class SsoException extends RuntimeException {
        private final String code;
        public SsoException(String code, String message) { super(message); this.code = code; }
        public String code() { return code; }
    }
    public static class NotFound extends SsoException { public NotFound(String c, String m){super(c,m);} }
    public static class Forbidden extends SsoException { public Forbidden(String c, String m){super(c,m);} }
    public static class Unauthorized extends SsoException { public Unauthorized(String c, String m){super(c,m);} }
    public static class Conflict extends SsoException { public Conflict(String c, String m){super(c,m);} }
    public static class Validation extends SsoException {
        private final String field; private final String rule;
        public Validation(String field, String rule, String message){super("VALIDATION_FAILED",message);this.field=field;this.rule=rule;}
        public String field(){return field;} public String rule(){return rule;}
    }
}
