package com.company.sso.api;

import com.company.sso.api.ApiModels.*;
import com.company.sso.error.SsoExceptions.*;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Validation.class)
    ResponseEntity<ErrorResponse> validation(Validation ex) {
        return ResponseEntity.badRequest().body(new ErrorResponse(
                ex.code(), "Please correct the highlighted fields.",
                List.of(new FieldError(ex.field(), ex.rule(), ex.getMessage())), tracking()));
    }
    @ExceptionHandler(NotFound.class)
    ResponseEntity<ErrorResponse> notFound(NotFound ex){ return response(HttpStatus.NOT_FOUND, ex); }
    @ExceptionHandler(Forbidden.class)
    ResponseEntity<ErrorResponse> forbidden(Forbidden ex){ return response(HttpStatus.FORBIDDEN, ex); }
    @ExceptionHandler(Unauthorized.class)
    ResponseEntity<ErrorResponse> unauthorized(Unauthorized ex){ return response(HttpStatus.UNAUTHORIZED, ex); }
    @ExceptionHandler(Conflict.class)
    ResponseEntity<ErrorResponse> conflict(Conflict ex){ return response(HttpStatus.CONFLICT, ex); }
    @ExceptionHandler(SsoException.class)
    ResponseEntity<ErrorResponse> known(SsoException ex){ return response(HttpStatus.BAD_REQUEST, ex); }
    @ExceptionHandler(Exception.class)
    ResponseEntity<ErrorResponse> unexpected(Exception ex){
        return ResponseEntity.status(500).body(new ErrorResponse("INTERNAL_ERROR",
                "The request could not be completed.", List.of(), tracking()));
    }
    private ResponseEntity<ErrorResponse> response(HttpStatus status, SsoException ex){
        return ResponseEntity.status(status).body(new ErrorResponse(ex.code(), ex.getMessage(), List.of(), tracking()));
    }
    private String tracking(){ return UUID.randomUUID().toString(); }
}
