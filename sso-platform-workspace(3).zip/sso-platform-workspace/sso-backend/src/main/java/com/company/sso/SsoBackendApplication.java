package com.company.sso;
import com.company.sso.config.AuthProperties;
import com.company.sso.external.ExternalLoginProperties;
import com.company.sso.clientlog.ClientLogProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
@SpringBootApplication
@EnableConfigurationProperties({AuthProperties.class, ExternalLoginProperties.class, ClientLogProperties.class})
public class SsoBackendApplication { public static void main(String[] args){ SpringApplication.run(SsoBackendApplication.class,args); } }
