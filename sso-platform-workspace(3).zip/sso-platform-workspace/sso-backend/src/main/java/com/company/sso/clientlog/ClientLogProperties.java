package com.company.sso.clientlog;

import java.time.Duration;
import java.util.Set;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "client-logging")
public record ClientLogProperties(
        boolean enabled,
        int maxBatchesPerWindow,
        Duration rateLimitWindow,
        int maxMessageLength,
        int maxMetadataValueLength,
        Set<String> allowedEventCodes) {}
