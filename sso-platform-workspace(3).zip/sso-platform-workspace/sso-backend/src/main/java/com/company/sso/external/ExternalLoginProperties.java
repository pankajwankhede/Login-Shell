package com.company.sso.external;
import org.springframework.boot.context.properties.ConfigurationProperties;
@ConfigurationProperties(prefix="external-login") public record ExternalLoginProperties(String baseUrl,boolean mockEnabled){}
