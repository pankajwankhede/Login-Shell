package com.company.sso.external;

import com.company.sso.domain.Models.*;
import java.util.Map;

public interface ExternalLoginClient {
    ExternalUser authenticate(String realm, String username, String password);
    ExternalUser refresh(String realm, String userReference);
    RecoveryStartResult startForgotPassword(String realm, String username);
    RecoveryVerifyResult verifyForgotPassword(String realm, String challengeId, String code);
    void completeForgotPassword(String realm, String userReference, String newPassword);
    RecoveryStartResult startForgotUsername(String realm, Map<String,String> identityData);
    RecoveryVerifyResult verifyForgotUsername(String realm, String challengeId, String code);
    String completeForgotUsername(String realm, String userReference);
    void updateExpiredPassword(String realm, String userReference, String newPassword);
    ExternalUser updateProfile(String realm, String userReference, Map<String,String> profile);
    TransmitStartResult startTransmit(String realm, String userReference);
    TransmitCompleteResult completeTransmit(String realm, String journeyId, String resultReference);
}
