package com.company.sso.api;

import com.company.sso.api.ApiModels.*;
import com.company.sso.domain.Models.Flow;
import com.company.sso.service.*;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class PostAuthenticationController {
    private final PostAuthenticationFlowService flows; private final SsoService sso; private final ValidationService validation;
    public PostAuthenticationController(PostAuthenticationFlowService f,SsoService s,ValidationService v){flows=f;sso=s;validation=v;}
    @PostMapping("/password-expired/update") public ActionResponse password(@RequestBody PasswordUpdateRequest b,HttpServletRequest req){var session=req.getSession(false);var r=sso.requiredRequest(session,b.requestId());String username=sso.requestUser(session,b.requestId()).map(x->x.username()).orElse(null);validation.password(r.realm(),username,b.newPassword(),b.confirmPassword());flows.updateExpiredPassword(session,b.requestId(),b.newPassword());return ActionResponse.next(b.requestId(),Flow.COMPLETE.name());}
    @PutMapping("/profile") public ActionResponse profile(@RequestBody ProfileUpdateRequest b,HttpServletRequest req){flows.updateProfile(req.getSession(false),b.requestId(),b.profile());return ActionResponse.next(b.requestId(),Flow.COMPLETE.name());}
    @PostMapping("/transmit/start") public ActionResponse transmitStart(@RequestParam String requestId,HttpServletRequest req){var x=flows.startTransmit(req.getSession(false),requestId);return new ActionResponse(requestId,Flow.TRANSMIT.name(),null,Map.of("journeyId",x.journeyId(),"sdkConfig",x.sdkConfig()));}
    @PostMapping("/transmit/complete") public ActionResponse transmitComplete(@RequestBody TransmitCompleteRequest b,HttpServletRequest req){flows.completeTransmit(req.getSession(false),b.requestId(),b.resultReference());return ActionResponse.next(b.requestId(),Flow.COMPLETE.name());}
}
