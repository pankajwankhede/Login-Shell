package com.company.sso.remember;

import com.company.sso.domain.Models.ExternalUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Optional;

public interface RememberMeManager {
    void issue(String realm, ExternalUser user, HttpServletResponse response);
    Optional<ExternalUser> restore(String realm, HttpServletRequest request, HttpServletResponse response);
    void revokeCurrent(HttpServletRequest request, HttpServletResponse response);
    void revokeAll(String realm, String userId);
}
