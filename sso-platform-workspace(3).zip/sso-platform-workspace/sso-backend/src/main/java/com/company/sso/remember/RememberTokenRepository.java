package com.company.sso.remember;

import java.time.Instant;
import java.util.Optional;

public interface RememberTokenRepository {
    record TokenRecord(String seriesId,String tokenHash,String realm,String userId,String userReference,Instant expiresAt,boolean revoked) {}
    void save(TokenRecord record); Optional<TokenRecord> find(String seriesId); void revoke(String seriesId); void revokeAll(String realm,String userId);
}
