package com.company.sso.remember;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

@Component
public class InMemoryRememberTokenRepository implements RememberTokenRepository {
    private final ConcurrentHashMap<String,TokenRecord> records=new ConcurrentHashMap<>();
    public void save(TokenRecord record){records.put(record.seriesId(),record);} public Optional<TokenRecord> find(String id){return Optional.ofNullable(records.get(id));}
    public void revoke(String id){records.computeIfPresent(id,(k,v)->new TokenRecord(v.seriesId(),v.tokenHash(),v.realm(),v.userId(),v.userReference(),v.expiresAt(),true));}
    public void revokeAll(String realm,String userId){records.replaceAll((k,v)->v.realm().equals(realm)&&v.userId().equals(userId)?new TokenRecord(v.seriesId(),v.tokenHash(),v.realm(),v.userId(),v.userReference(),v.expiresAt(),true):v);}
}
