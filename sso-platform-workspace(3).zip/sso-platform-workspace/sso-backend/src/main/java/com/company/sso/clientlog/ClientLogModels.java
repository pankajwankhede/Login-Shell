package com.company.sso.clientlog;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public final class ClientLogModels {
    private ClientLogModels() {}

    public enum ClientLogLevel { INFO, WARN, ERROR }

    public record ClientLogRequest(
            @NotNull ClientLogLevel level,
            @NotBlank @Size(max = 100) String eventCode,
            @Size(max = 1000) String message,
            @Size(max = 100) String requestId,
            @Size(max = 100) String journeyId,
            @Size(max = 50) String realm,
            @Size(max = 50) String flow,
            @Size(max = 100) String component,
            @Size(max = 500) String route,
            @Size(max = 100) String trackingId,
            @NotNull Instant timestamp,
            @Size(max = 20) Map<@Size(max = 80) String, Object> metadata) {}

    public record ClientLogBatchRequest(
            @NotEmpty @Size(max = 50) List<@Valid ClientLogRequest> events) {}
}
