package com.company.sso.api;

import com.company.sso.config.AuthProperties.*;
import java.util.List;
import java.util.Map;

public final class ApiModels {
    private ApiModels() {}

    public record SsoStartResponse(String requestId, String flowUrl) {}
    public record UserSummary(String displayName, String realm) {}
    public record BootstrapResponse(
            String requestId, String realm, String clientId, boolean authenticated,
            String nextAction, String layout, FlowProperties features,
            LayoutProperties uiConfiguration, ValidationProperties validation,
            SessionPolicy sessionPolicy, UserSummary user) {}
    public record ActionResponse(String requestId, String nextAction, String redirectUrl,
                                 Map<String, Object> data) {
        public static ActionResponse next(String id, String action) {
            return new ActionResponse(id, action, null, Map.of());
        }
    }
    public record AuthenticateRequest(String requestId, String username, String password,
                                      Boolean rememberMe) {}
    public record PasswordUpdateRequest(String requestId, String newPassword, String confirmPassword) {}
    public record RecoveryStartRequest(String requestId, String username, String email, String phone) {}
    public record RecoveryVerifyRequest(String requestId, String verificationCode) {}
    public record ForgotPasswordCompleteRequest(String requestId, String newPassword, String confirmPassword) {}
    public record ProfileUpdateRequest(String requestId, Map<String, String> profile) {}
    public record TransmitCompleteRequest(String requestId, String resultReference) {}
    public record LogoutRequest(String requestId, String realm, boolean global, boolean revokeRememberMe) {}
    public record FieldError(String field, String rule, String message) {}
    public record ErrorResponse(String code, String message, List<FieldError> fieldErrors, String trackingId) {}
}
