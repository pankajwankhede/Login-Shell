package com.company.sso.service;

import com.company.sso.domain.Models.*;
import com.company.sso.error.SsoExceptions.Unauthorized;
import com.company.sso.external.ExternalLoginClient;
import com.company.sso.session.SessionStateRepository;
import jakarta.servlet.http.HttpSession;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class RecoveryService {
    private final SsoService sso; private final ExternalLoginClient login; private final SessionStateRepository repo;
    public RecoveryService(SsoService sso,ExternalLoginClient login,SessionStateRepository repo){this.sso=sso;this.login=login;this.repo=repo;}
    public RecoveryStartResult startPassword(HttpSession session,String id,String username){SsoRequest r=sso.requiredRequest(session,id);sso.beginJourney(session,id,Flow.FORGOT_PASSWORD);var result=login.startForgotPassword(r.realm(),username);Journey j=sso.requiredJourney(session,id,Flow.FORGOT_PASSWORD);sso.updateJourney(session,j,Flow.FORGOT_PASSWORD,JourneyStatus.CHALLENGE_SENT,null,result.challengeId(),null,Map.of("username",username));return result;}
    public void verifyPassword(HttpSession session,String id,String code){Journey j=sso.requiredJourney(session,id,Flow.FORGOT_PASSWORD);var result=login.verifyForgotPassword(j.realm(),j.challengeId(),code);if(!result.verified())throw new Unauthorized("INVALID_VERIFICATION_CODE","Verification code is invalid.");sso.updateJourney(session,j,Flow.FORGOT_PASSWORD,JourneyStatus.VERIFIED,result.userReference(),j.challengeId(),null,j.metadata());}
    public void completePassword(HttpSession session,String id,String password){Journey j=sso.requiredJourney(session,id,Flow.FORGOT_PASSWORD);if(j.status()!=JourneyStatus.VERIFIED)throw new Unauthorized("RECOVERY_NOT_VERIFIED","Recovery verification is required.");login.completeForgotPassword(j.realm(),j.userReference(),password);repo.removeJourney(session,id);}
    public RecoveryStartResult startUsername(HttpSession session,String id,Map<String,String> identity){SsoRequest r=sso.requiredRequest(session,id);sso.beginJourney(session,id,Flow.FORGOT_USERNAME);var result=login.startForgotUsername(r.realm(),identity);Journey j=sso.requiredJourney(session,id,Flow.FORGOT_USERNAME);sso.updateJourney(session,j,Flow.FORGOT_USERNAME,JourneyStatus.CHALLENGE_SENT,null,result.challengeId(),null,identity);return result;}
    public void verifyUsername(HttpSession session,String id,String code){Journey j=sso.requiredJourney(session,id,Flow.FORGOT_USERNAME);var result=login.verifyForgotUsername(j.realm(),j.challengeId(),code);if(!result.verified())throw new Unauthorized("INVALID_VERIFICATION_CODE","Verification code is invalid.");sso.updateJourney(session,j,Flow.FORGOT_USERNAME,JourneyStatus.VERIFIED,result.userReference(),j.challengeId(),null,j.metadata());}
    public String completeUsername(HttpSession session,String id){Journey j=sso.requiredJourney(session,id,Flow.FORGOT_USERNAME);if(j.status()!=JourneyStatus.VERIFIED)throw new Unauthorized("RECOVERY_NOT_VERIFIED","Recovery verification is required.");String username=login.completeForgotUsername(j.realm(),j.userReference());repo.removeJourney(session,id);return username;}
}
