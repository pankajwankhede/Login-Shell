package com.company.sso.api;

import com.company.sso.api.ApiModels.*;
import com.company.sso.domain.Models.Flow;
import com.company.sso.service.*;
import jakarta.servlet.http.*;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class AuthenticationController {
    private final SsoService sso; private final ValidationService validation;
    public AuthenticationController(SsoService sso,ValidationService validation){this.sso=sso;this.validation=validation;}
    @PostMapping("/authenticate") public ActionResponse authenticate(@RequestBody AuthenticateRequest body,HttpServletRequest req,HttpServletResponse res){var r=sso.requiredRequest(req.getSession(false),body.requestId());String username=validation.username(r.realm(),body.username());Flow next=sso.authenticate(req,res,body.requestId(),username,body.password(),Boolean.TRUE.equals(body.rememberMe()));return ActionResponse.next(body.requestId(),next.name());}
    @PostMapping("/authorize/complete") public ActionResponse authorize(@RequestParam String requestId,HttpServletRequest req){return sso.completeAuthorization(req.getSession(false),requestId);}
    @PostMapping("/logout") public void logout(@RequestBody LogoutRequest body,HttpServletRequest req,HttpServletResponse res){if(body.revokeRememberMe())sso.revokeRemember(req,res);sso.logout(req.getSession(false),body.requestId(),body.realm(),body.global());}
}
