package com.company.sso.clientlog;

import static com.company.sso.clientlog.ClientLogModels.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

@Service
public class ClientLogService {
    private static final Logger LOGGER = LoggerFactory.getLogger("CLIENT_UI");
    private final ClientLogProperties properties;
    private final ClientLogSanitizer sanitizer;

    public ClientLogService(ClientLogProperties properties, ClientLogSanitizer sanitizer) {
        this.properties = properties;
        this.sanitizer = sanitizer;
    }

    public void log(ClientLogRequest event, HttpServletRequest request) {
        if (!properties.enabled() || !properties.allowedEventCodes().contains(event.eventCode())) return;
        String trackingId = Optional.ofNullable(event.trackingId()).filter(v -> !v.isBlank()).orElseGet(() -> UUID.randomUUID().toString());
        put("trackingId", trackingId);
        put("requestId", event.requestId());
        put("journeyId", event.journeyId());
        put("realm", event.realm());
        put("flow", event.flow());
        put("component", event.component());
        put("eventCode", event.eventCode());
        put("source", "REACT_UI");
        put("clientIp", request.getRemoteAddr());
        try {
            String message = sanitizer.sanitizeMessage(event.message());
            Map<String, Object> metadata = sanitizer.sanitizeMetadata(event.metadata());
            String template = "clientEvent={} clientTimestamp={} route={} message={} metadata={}";
            switch (event.level()) {
                case INFO -> LOGGER.info(template, event.eventCode(), event.timestamp(), event.route(), message, metadata);
                case WARN -> LOGGER.warn(template, event.eventCode(), event.timestamp(), event.route(), message, metadata);
                case ERROR -> LOGGER.error(template, event.eventCode(), event.timestamp(), event.route(), message, metadata);
            }
        } finally {
            MDC.clear();
        }
    }

    private static void put(String key, String value) { if (value != null && !value.isBlank()) MDC.put(key, value); }
}
