package com.company.sso.session;

import com.company.sso.domain.Models.*;
import jakarta.servlet.http.HttpSession;
import java.time.Instant;
import java.util.*;
import org.springframework.stereotype.Component;

@Component
public class SessionStateRepository {
    private static final String REQUESTS="SSO_REQUESTS", REALM_USERS="REALM_USERS",
            REQUEST_USERS="REQUEST_USERS", JOURNEYS="AUTH_JOURNEYS";

    @SuppressWarnings("unchecked")
    private <T> Map<String,T> map(HttpSession session, String key){
        if(session == null) return Map.of();
        Object value = session.getAttribute(key);
        return value instanceof Map<?,?> ? (Map<String,T>) value : Map.of();
    }
    private <T> void put(HttpSession s,String key,String id,T value){
        Map<String,T> copy = new HashMap<>(map(s,key)); copy.put(id,value); s.setAttribute(key, Map.copyOf(copy));
    }
    private void remove(HttpSession s,String key,String id){
        if(s==null)return; Map<String,Object> copy=new HashMap<>(map(s,key)); copy.remove(id); s.setAttribute(key,Map.copyOf(copy));
    }
    public void saveRequest(HttpSession s,SsoRequest r){put(s,REQUESTS,r.requestId(),r);}    
    public Optional<SsoRequest> request(HttpSession s,String id){return Optional.ofNullable(this.<SsoRequest>map(s,REQUESTS).get(id));}
    public void saveRealmUser(HttpSession s,String realm,RealmUserContext u){put(s,REALM_USERS,realm,u);}
    public Optional<RealmUserContext> realmUser(HttpSession s,String realm){return Optional.ofNullable(this.<RealmUserContext>map(s,REALM_USERS).get(realm));}
    public Map<String,RealmUserContext> realmUsers(HttpSession s){return Map.copyOf(this.<RealmUserContext>map(s,REALM_USERS));}
    public void removeRealmUser(HttpSession s,String realm){remove(s,REALM_USERS,realm);}
    public void saveRequestUser(HttpSession s,RequestUserContext u){put(s,REQUEST_USERS,u.requestId(),u);}
    public Optional<RequestUserContext> requestUser(HttpSession s,String requestId){return Optional.ofNullable(this.<RequestUserContext>map(s,REQUEST_USERS).get(requestId));}
    public void removeRequestUser(HttpSession s,String id){remove(s,REQUEST_USERS,id);}
    public void saveJourney(HttpSession s,Journey j){put(s,JOURNEYS,j.requestId(),j);}
    public Optional<Journey> journey(HttpSession s,String id){return Optional.ofNullable(this.<Journey>map(s,JOURNEYS).get(id));}
    public void removeJourney(HttpSession s,String id){remove(s,JOURNEYS,id);}
    public void removeRequest(HttpSession s,String id){remove(s,REQUESTS,id);}
    public void cleanupRequest(HttpSession s,String id){removeRequest(s,id);removeJourney(s,id);removeRequestUser(s,id);}
    public void cleanupExpired(HttpSession s){
        if(s==null)return; Instant now=Instant.now();
        this.<SsoRequest>map(s,REQUESTS).values().stream().filter(x->!x.expiresAt().isAfter(now)).map(SsoRequest::requestId).toList().forEach(id->cleanupRequest(s,id));
        this.<Journey>map(s,JOURNEYS).values().stream().filter(x->!x.expiresAt().isAfter(now)).map(Journey::requestId).toList().forEach(id->cleanupRequest(s,id));
        this.<RealmUserContext>map(s,REALM_USERS).forEach((realm,u)->{if(!u.expiresAt().isAfter(now)) removeRealmUser(s,realm);});
    }
    public boolean empty(HttpSession s){return map(s,REQUESTS).isEmpty()&&map(s,REALM_USERS).isEmpty()&&map(s,JOURNEYS).isEmpty()&&map(s,REQUEST_USERS).isEmpty();}
}
