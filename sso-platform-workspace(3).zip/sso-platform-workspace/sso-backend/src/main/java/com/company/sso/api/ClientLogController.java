package com.company.sso.api;

import static com.company.sso.clientlog.ClientLogModels.ClientLogBatchRequest;
import static com.company.sso.clientlog.ClientLogModels.ClientLogRequest;

import com.company.sso.clientlog.ClientLogRateLimiter;
import com.company.sso.clientlog.ClientLogService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Receives sanitized telemetry events from the React application.
 *
 * <p>Endpoints:
 * <ul>
 *   <li>POST /api/client-logs</li>
 *   <li>POST /api/client-logs/batch</li>
 * </ul>
 *
 * <p>Business/security audit events must still be written by backend services.
 */
@RestController
@RequestMapping("/api/client-logs")
public class ClientLogController {

    private final ClientLogService clientLogService;
    private final ClientLogRateLimiter rateLimiter;

    public ClientLogController(
            ClientLogService clientLogService,
            ClientLogRateLimiter rateLimiter) {
        this.clientLogService = clientLogService;
        this.rateLimiter = rateLimiter;
    }

    @PostMapping
    public ResponseEntity<Void> log(
            @Valid @RequestBody ClientLogRequest event,
            HttpServletRequest request) {

        if (!rateLimiter.allow(request)) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }

        clientLogService.log(event, request);
        return ResponseEntity.accepted().build();
    }

    @PostMapping("/batch")
    public ResponseEntity<Void> logBatch(
            @Valid @RequestBody ClientLogBatchRequest batch,
            HttpServletRequest request) {

        if (!rateLimiter.allow(request)) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }

        batch.events().forEach(event -> clientLogService.log(event, request));
        return ResponseEntity.accepted().build();
    }
}
