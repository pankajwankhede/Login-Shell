package com.company.sso.api;

import com.company.sso.api.ApiModels.*;
import com.company.sso.domain.Models.SsoRequest;
import com.company.sso.service.SsoService;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
public class SsoEntryController {
    private final SsoService service; public SsoEntryController(SsoService s){service=s;}
    @GetMapping("/login/ssoAuthenticate")
    public ResponseEntity<Void> start(@RequestParam String clientId,@RequestParam String redirectUri,
      @RequestParam String realm,@RequestParam(required=false) String state,@RequestParam(required=false) String scope,
      @RequestParam(required=false,defaultValue="code") String responseType,HttpServletRequest req){
        SsoRequest r=service.start(req,clientId,redirectUri,realm,state,scope,responseType);
        return ResponseEntity.status(HttpStatus.FOUND).location(URI.create("/login/flow/"+r.requestId())).build();
    }
}
