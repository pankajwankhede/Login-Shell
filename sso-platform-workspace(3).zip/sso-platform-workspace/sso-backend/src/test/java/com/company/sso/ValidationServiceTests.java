package com.company.sso;
import static org.junit.jupiter.api.Assertions.*;
import com.company.sso.config.AuthProperties;
import com.company.sso.realm.RealmPolicyService;
import com.company.sso.service.ValidationService;
import java.time.Duration;import java.util.*;import org.junit.jupiter.api.Test;
class ValidationServiceTests {
 @Test void validatesRealmUsername(){var text=new AuthProperties.TextRule(true,3,10,"^[A-Z]+$",true,Map.of());var pwd=new AuthProperties.PasswordRule(true,8,20,true,true,true,false,"",true,true,0,Map.of());var validation=new AuthProperties.ValidationProperties(text,pwd,text,text);var flows=new AuthProperties.FlowProperties(true,true,true,true,true,true,false);var session=new AuthProperties.SessionPolicy(AuthProperties.SessionMode.REALM_CONTEXT,Duration.ofHours(1),true,false);var layout=new AuthProperties.LayoutProperties("","","","","","","",List.of(),List.of(),List.of());var realm=new AuthProperties.RealmProperties(true,List.of("c"),List.of("https://x"),List.of(),AuthProperties.SameRealmUserPolicy.ISOLATE_BY_REQUEST,flows,session,new AuthProperties.UiProperties(layout,layout),validation,Map.of());var props=new AuthProperties(Duration.ofMinutes(10),Duration.ofMinutes(10),new AuthProperties.RememberMeGlobal("R",Duration.ofDays(1),"k"),Map.of("BCA",realm));var service=new ValidationService(new RealmPolicyService(props));assertEquals("ABC",service.username("BCA"," ABC "));assertThrows(RuntimeException.class,()->service.username("BCA","a"));}
}
