package com.company.sso;

import static org.assertj.core.api.Assertions.assertThat;
import com.company.sso.clientlog.*;
import java.time.Duration;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;

class ClientLogSanitizerTests {
    @Test void removesSensitiveMetadata() {
        ClientLogProperties properties = new ClientLogProperties(true, 10, Duration.ofMinutes(1), 1000, 500, Set.of("WINDOW_ERROR"));
        ClientLogSanitizer sanitizer = new ClientLogSanitizer(properties);
        assertThat(sanitizer.sanitizeMetadata(Map.of("password", "secret", "errorCode", "E1")))
                .containsEntry("errorCode", "E1").doesNotContainKey("password");
    }
}
