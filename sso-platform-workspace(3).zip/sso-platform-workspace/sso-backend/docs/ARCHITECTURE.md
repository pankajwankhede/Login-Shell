# Architecture
- One `SSOSESSION` cookie and one distributed Spring Session.
- `SSO_REQUESTS[requestId]`: tab-safe relying-party requests.
- `REALM_USERS[realm]`: reusable realm identity context.
- `AUTH_JOURNEYS[requestId]`: protected next-action state.
- Realm policy comes from Config Server/YAML and controls flows, validation, UI and realm expiry.
- IH/transient realms do not retain a reusable realm context.
- Redirect URIs are allowlisted; React never chooses trusted realm/client values.
