# SSO Backend
Greenfield Spring Boot SSO orchestration service.

Implemented: requestId multi-tab isolation, realm flow policies, per-realm context expiry, cross-realm reuse, transient realms, all six flows, UI/validation bootstrap, CSRF endpoint, mock/remote login adapters, remember-me token rotation abstraction, realm/global logout, authorization completion redirect, structured errors.

Production adapters still require company values: approved Spring Session Data GemFire artifact and cluster settings, external service payload mapping, durable RememberTokenRepository (DB or identity service), Transmit SDK/server verification, real OAuth authorization-code persistence/signing, Vault secrets, registered clients, CSP/script allowlist, rate limiter and audit sink.

## React client logging

The backend exposes:

- `POST /api/client-logs` for one structured event
- `POST /api/client-logs/batch` for up to 50 events

The endpoints require the normal CSRF cookie/header pair. Events are allowlisted, rate limited, sanitized and written through the `CLIENT_UI` SLF4J logger with MDC fields such as `trackingId`, `requestId`, `realm`, `flow`, `component`, `eventCode` and `source=REACT_UI`.

Use the separate `@company/sso-client-logger` package from the workspace. Never send passwords, OTPs, cookies, tokens, full user objects or financial identifiers.

## React client logging endpoints

Controller location:

```text
src/main/java/com/company/sso/api/ClientLogController.java
```

Endpoints:

```text
POST /api/client-logs
POST /api/client-logs/batch
```
