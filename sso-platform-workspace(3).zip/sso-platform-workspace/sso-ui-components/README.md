# sso-ui-components
Realm-driven headers, footers, fields and layout primitives.

```bash
npm install && npm run build
```
