# sso-flow-forgot-password
Reusable ForgotPasswordFlow package.

```bash
npm install && npm run build
```
