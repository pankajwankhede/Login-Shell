# SSO React Shell
Host application that bootstraps realm configuration and renders independently packaged flows.

Run all sibling packages first or use the combined workspace ZIP:
```bash
npm install
npm run dev
```
Example entry:
`http://localhost:8080/login/ssoAuthenticate?clientId=bca-web&redirectUri=https://bca.company.com/callback&realm=BCA`

## Client logging

The shell consumes `@company/sso-client-logger`. Call `configureClientLogging()` once during application startup, then use `setAuthLoggingContext(...)` after bootstrap. Flow packages may emit approved event codes through the shared logger. Business success/failure audit events remain authoritative in the Spring backend.
