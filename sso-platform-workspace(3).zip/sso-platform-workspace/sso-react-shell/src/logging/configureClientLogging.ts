import { ssoClientLogger } from "@company/sso-client-logger";

export function configureClientLogging(): () => void {
  ssoClientLogger.start();
  const unregisterGlobalHandlers = ssoClientLogger.registerGlobalHandlers();
  return () => {
    unregisterGlobalHandlers();
    ssoClientLogger.stop();
  };
}

export function setAuthLoggingContext(input: {
  requestId?: string;
  journeyId?: string;
  realm?: string;
  flow?: string;
  component?: string;
}): void {
  ssoClientLogger.setContext(input);
}
