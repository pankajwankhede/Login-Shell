import React from "react";
import {createRoot} from "react-dom/client";
import {BrowserRouter, Navigate, Route, Routes} from "react-router-dom";
import {QueryClient,QueryClientProvider} from "@tanstack/react-query";
import "@company/sso-ui-components/dist/styles.css";
import App from "./App";
const queryClient=new QueryClient();
createRoot(document.getElementById("root")!).render(
  <React.StrictMode><QueryClientProvider client={queryClient}><BrowserRouter><Routes>
    <Route path="/login/flow/:id" element={<App/>}/>
    <Route path="*" element={<Navigate to="/login/error" replace/>}/>
  </Routes></BrowserRouter></QueryClientProvider></React.StrictMode>
);
