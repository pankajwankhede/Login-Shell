# Sample Relying Party
Tiny Node app showing the SSO entry link.
