# Implementation Matrix

## Implemented reference code

- SSO entry and registered redirect validation
- Backend-generated requestId and tab-isolated authorization requests
- One HttpSession with GemFire-compatible serializable maps
- Realm user and request user contexts
- Realm flow feature flags
- Realm UI/bootstrap configuration
- Realm validation rules/messages and backend enforcement
- Per-realm fixed/sliding context expiration
- Cross-realm allow-from resolution
- Transient IH-style realm cleanup
- Authenticate, forgot password, forgot username, password expired, missing profile and Transmit orchestration
- Public/authenticated React layouts
- Reusable React flow packages
- CSRF cookie endpoint/client initialization
- Realm/global logout
- Remember-me opaque cookie, token hashing, rotation and revocation interface
- Local in-memory remember-token repository
- Mock and WebClient external-login adapters
- Structured API errors
- Mock authorization code and final RP redirect

## Production adapters that must be replaced with company implementations

- Approved Spring Session Data GemFire dependency and locator/region/TLS settings
- Durable RememberTokenRepository (external identity service or enterprise DB)
- Exact external login-service paths, request/response DTOs and auth headers
- Real OAuth authorization-code repository, signing and token exchange
- Actual Transmit SDK/server verification
- Vault/Config Server credentials
- Enterprise client registry and redirect allowlist source
- Audit/event sink, rate limits, fraud/risk decisions and secret masking
- Company CSP script hashes and static asset deployment

These are adapter boundaries because their values and APIs were not supplied; no fabricated credentials or vendor contracts are included.
