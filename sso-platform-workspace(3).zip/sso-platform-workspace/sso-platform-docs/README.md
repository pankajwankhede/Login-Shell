# SSO Platform Delivery Guide
All repositories are designed so different developers can work concurrently after agreeing on `sso-auth-core` and backend API contracts.

## Suggested ownership
1. Backend foundation/session/realm policy
2. External login-service integration
3. React shell/layout/bootstrap
4. Shared UI library
5. Authenticate flow
6. Forgot-password flow
7. Forgot-username flow
8. Password-expired flow
9. Missing-profile flow
10. Transmit flow + SDK adapter
11. Security/Remember-Me/CSRF/rate limiting
12. Integration and Playwright tests

## Contract freeze
Freeze these first: bootstrap response, `requestId`, flow names, structured errors, validation metadata, realm policy YAML.
