# React-to-Backend Client Logging

## Purpose
Capture browser-side rendering, navigation, validation and SDK errors without using production `console.log` statements.

## Endpoints
- `POST /api/client-logs`
- `POST /api/client-logs/batch`

## Controls
- CSRF protected
- Credentials included
- Event-code allowlist
- Maximum 50 events per batch
- Rate limiting per active session or remote IP
- Metadata key/value limits
- Sensitive-key sanitization
- MDC correlation for Splunk/backend logs
- Bounded client queue and bounded retry

## Responsibility split
React reports UI telemetry. Spring records authoritative authentication, session, password, profile, authorization and logout events.
