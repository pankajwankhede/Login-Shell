# Production integrations still organization-specific
- Approved Spring Session Data GemFire dependency and cluster locator configuration
- Real external login/recovery/profile/password APIs and their error mappings
- Remember-Me token owner/store and revocation endpoints
- Transmit SDK package/configuration
- OAuth authorization-code issuance and relying-party redirect continuation
- Config Server/Vault URLs and credentials
- Rate limiter, audit sink/Splunk fields, CSP approved script hashes
- Nexus/npm publishing and enterprise CI templates
