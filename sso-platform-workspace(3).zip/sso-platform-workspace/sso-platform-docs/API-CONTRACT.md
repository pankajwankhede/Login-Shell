# API Contract
- `GET /login/ssoAuthenticate?clientId=&redirectUri=&realm=&state=` creates a trusted request and redirects to `/login/flow/{requestId}`.
- `GET /api/auth/bootstrap/{requestId}` returns realm, next action, features, layout, UI, validation and session policy.
- Every mutation includes `requestId`; backend resolves realm/client from server session.
- Never trust realm, redirect URI or user identity resent from React.
