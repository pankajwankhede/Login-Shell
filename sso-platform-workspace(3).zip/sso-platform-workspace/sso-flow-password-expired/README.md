# sso-flow-password-expired
Reusable PasswordExpiredFlow package.

```bash
npm install && npm run build
```
