import type { ClientLogPrimitive } from "./types";

const BLOCKED_KEY_PATTERN = /(password|passwd|pwd|otp|token|secret|authorization|cookie|session(id)?|ssn|account(number)?|card(number)?|cvv|pin)/i;

export function sanitizeMessage(value: unknown, maxLength = 1000): string | undefined {
  if (typeof value !== "string") return undefined;
  return value.replace(/[\r\n\t]+/g, " ").trim().slice(0, maxLength);
}

export function sanitizeMetadata(
  metadata: Record<string, unknown> | undefined,
  maxValueLength = 500,
): Record<string, ClientLogPrimitive> | undefined {
  if (!metadata) return undefined;
  const safe: Record<string, ClientLogPrimitive> = {};
  for (const [key, raw] of Object.entries(metadata)) {
    if (BLOCKED_KEY_PATTERN.test(key)) continue;
    if (typeof raw === "string") safe[key] = raw.replace(/[\r\n\t]+/g, " ").slice(0, maxValueLength);
    else if (typeof raw === "number" && Number.isFinite(raw)) safe[key] = raw;
    else if (typeof raw === "boolean") safe[key] = raw;
  }
  return Object.keys(safe).length ? safe : undefined;
}

export function readCookie(name: string): string | undefined {
  if (typeof document === "undefined") return undefined;
  const prefix = `${encodeURIComponent(name)}=`;
  return document.cookie
    .split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(prefix))
    ?.slice(prefix.length);
}
