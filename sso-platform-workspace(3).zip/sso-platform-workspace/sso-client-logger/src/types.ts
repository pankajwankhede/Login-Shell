export type ClientLogLevel = "INFO" | "WARN" | "ERROR";

export type ClientLogPrimitive = string | number | boolean;

export interface ClientLogEvent {
  level: ClientLogLevel;
  eventCode: string;
  message?: string;
  requestId?: string;
  journeyId?: string;
  realm?: string;
  flow?: string;
  component?: string;
  route?: string;
  trackingId?: string;
  timestamp: string;
  metadata?: Record<string, ClientLogPrimitive>;
}

export interface ClientLogContext {
  requestId?: string;
  journeyId?: string;
  realm?: string;
  flow?: string;
  component?: string;
}

export interface ClientLoggerOptions {
  endpoint?: string;
  batchSize?: number;
  flushIntervalMs?: number;
  maxQueueSize?: number;
  maxMessageLength?: number;
  maxMetadataValueLength?: number;
  allowedEventCodes?: readonly string[];
  csrfCookieName?: string;
  csrfHeaderName?: string;
  fetchImpl?: typeof fetch;
}
