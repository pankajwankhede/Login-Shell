export * from "./types";
export * from "./sanitize";
export * from "./clientLogger";

import { SsoClientLogger } from "./clientLogger";

export const ssoClientLogger = new SsoClientLogger({
  allowedEventCodes: [
    "LOGIN_PAGE_LOADED",
    "AUTHENTICATION_STARTED",
    "AUTHENTICATION_FAILED",
    "FORGOT_PASSWORD_STARTED",
    "FORGOT_USERNAME_STARTED",
    "PASSWORD_EXPIRED_PAGE_LOADED",
    "MISSING_PROFILE_PAGE_LOADED",
    "TRANSMIT_INITIALIZATION_FAILED",
    "CLIENT_VALIDATION_FAILED",
    "SESSION_EXPIRED",
    "WINDOW_ERROR",
    "UNHANDLED_PROMISE_REJECTION",
    "UNEXPECTED_UI_ERROR"
  ]
});
