import { readCookie, sanitizeMessage, sanitizeMetadata } from "./sanitize";
import type { ClientLogContext, ClientLogEvent, ClientLogLevel, ClientLoggerOptions } from "./types";

const DEFAULT_OPTIONS: Required<Omit<ClientLoggerOptions, "allowedEventCodes" | "fetchImpl">> = {
  endpoint: "/api/client-logs/batch",
  batchSize: 20,
  flushIntervalMs: 5000,
  maxQueueSize: 200,
  maxMessageLength: 1000,
  maxMetadataValueLength: 500,
  csrfCookieName: "XSRF-TOKEN",
  csrfHeaderName: "X-XSRF-TOKEN",
};

export class SsoClientLogger {
  private readonly options: typeof DEFAULT_OPTIONS & Pick<ClientLoggerOptions, "allowedEventCodes">;
  private readonly fetchImpl: typeof fetch;
  private queue: ClientLogEvent[] = [];
  private context: ClientLogContext = {};
  private timer?: number;
  private flushing = false;

  constructor(options: ClientLoggerOptions = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.fetchImpl = options.fetchImpl ?? fetch.bind(globalThis);
  }

  start(): void {
    if (typeof window === "undefined" || this.timer) return;
    this.timer = window.setInterval(() => void this.flush(), this.options.flushIntervalMs);
    window.addEventListener("pagehide", this.handlePageHide);
  }

  stop(): void {
    if (typeof window === "undefined") return;
    if (this.timer) window.clearInterval(this.timer);
    this.timer = undefined;
    window.removeEventListener("pagehide", this.handlePageHide);
  }

  setContext(context: ClientLogContext): void {
    this.context = { ...this.context, ...context };
  }

  clearContext(): void {
    this.context = {};
  }

  info(eventCode: string, message?: string, metadata?: Record<string, unknown>): void {
    this.enqueue("INFO", eventCode, message, metadata);
  }

  warn(eventCode: string, message?: string, metadata?: Record<string, unknown>): void {
    this.enqueue("WARN", eventCode, message, metadata);
  }

  error(eventCode: string, error?: unknown, metadata?: Record<string, unknown>): void {
    const message = error instanceof Error ? error.message : typeof error === "string" ? error : undefined;
    const errorMetadata = error instanceof Error ? { ...metadata, errorName: error.name } : metadata;
    this.enqueue("ERROR", eventCode, message, errorMetadata);
  }

  enqueue(level: ClientLogLevel, eventCode: string, message?: string, metadata?: Record<string, unknown>): void {
    if (!this.isAllowed(eventCode)) return;
    const event: ClientLogEvent = {
      level,
      eventCode: eventCode.slice(0, 100),
      message: sanitizeMessage(message, this.options.maxMessageLength),
      requestId: this.context.requestId,
      journeyId: this.context.journeyId,
      realm: this.context.realm,
      flow: this.context.flow,
      component: this.context.component,
      route: typeof window === "undefined" ? undefined : window.location.pathname,
      trackingId: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      metadata: sanitizeMetadata(metadata, this.options.maxMetadataValueLength),
    };
    if (this.queue.length >= this.options.maxQueueSize) this.queue.shift();
    this.queue.push(event);
    if (this.queue.length >= this.options.batchSize) void this.flush();
  }

  async flush(): Promise<void> {
    if (this.flushing || this.queue.length === 0) return;
    this.flushing = true;
    const events = this.queue.splice(0, this.options.batchSize);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      const csrf = readCookie(this.options.csrfCookieName);
      if (csrf) headers[this.options.csrfHeaderName] = decodeURIComponent(csrf);
      const response = await this.fetchImpl(this.options.endpoint, {
        method: "POST",
        credentials: "include",
        keepalive: true,
        headers,
        body: JSON.stringify({ events }),
      });
      if (!response.ok && response.status >= 500) this.requeue(events);
    } catch {
      this.requeue(events);
    } finally {
      this.flushing = false;
    }
  }

  registerGlobalHandlers(): () => void {
    if (typeof window === "undefined") return () => undefined;
    const onError = (event: ErrorEvent) => this.error("WINDOW_ERROR", event.error ?? event.message, {
      filename: event.filename,
      line: event.lineno,
      column: event.colno,
    });
    const onRejection = (event: PromiseRejectionEvent) => this.error("UNHANDLED_PROMISE_REJECTION", event.reason);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onRejection);
    return () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onRejection);
    };
  }

  private readonly handlePageHide = (): void => {
    if (typeof navigator === "undefined" || this.queue.length === 0) return;
    const events = this.queue.splice(0, this.options.batchSize);
    const payload = new Blob([JSON.stringify({ events })], { type: "application/json" });
    if (!navigator.sendBeacon(this.options.endpoint, payload)) this.requeue(events);
  };

  private isAllowed(eventCode: string): boolean {
    return !this.options.allowedEventCodes || this.options.allowedEventCodes.includes(eventCode);
  }

  private requeue(events: ClientLogEvent[]): void {
    this.queue = [...events, ...this.queue].slice(0, this.options.maxQueueSize);
  }
}
