# @company/sso-client-logger

Reusable browser telemetry package for the Enterprise SSO React platform.

## Features
- No `console.log` dependency
- Structured event codes and correlation IDs
- Sensitive-field sanitization
- Bounded queue, batching and bounded retry
- CSRF cookie/header support
- `pagehide` delivery through `sendBeacon`
- Global error and unhandled promise rejection capture

## Usage
```ts
import { ssoClientLogger } from "@company/sso-client-logger";

ssoClientLogger.setContext({ requestId, realm, flow: "AUTHENTICATE" });
ssoClientLogger.start();
const unregister = ssoClientLogger.registerGlobalHandlers();

ssoClientLogger.info("LOGIN_PAGE_LOADED");
ssoClientLogger.warn("AUTHENTICATION_FAILED", "Authentication failed", { errorCode: "INVALID_CREDENTIALS" });
```

Never pass passwords, OTPs, cookies, tokens, full user objects or account numbers. The package sanitizes common sensitive keys, but callers remain responsible for safe event design.
