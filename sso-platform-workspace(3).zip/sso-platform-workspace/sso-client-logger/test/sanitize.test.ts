import { describe, expect, it } from "vitest";
import { sanitizeMetadata } from "../src/sanitize";

describe("sanitizeMetadata", () => {
  it("removes sensitive keys and unsupported values", () => {
    expect(sanitizeMetadata({ password: "secret", errorCode: "E1", retry: 1, nested: { a: 1 } }))
      .toEqual({ errorCode: "E1", retry: 1 });
  });
});
