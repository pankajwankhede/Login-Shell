# sso-flow-forgot-username
Reusable ForgotUsernameFlow package.

```bash
npm install && npm run build
```
