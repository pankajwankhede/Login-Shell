# sso-auth-core
Shared contracts for shell and all flow packages.

```bash
npm install && npm run build
```
