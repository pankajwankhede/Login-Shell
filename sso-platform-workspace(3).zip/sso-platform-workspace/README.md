# Complete SSO Platform Workspace

Parallel-ready greenfield reference implementation. See `sso-platform-docs/IMPLEMENTATION-MATRIX.md`.
