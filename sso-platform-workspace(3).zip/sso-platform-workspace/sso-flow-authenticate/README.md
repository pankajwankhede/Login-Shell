# sso-flow-authenticate
Reusable AuthenticateFlow package.

```bash
npm install && npm run build
```
